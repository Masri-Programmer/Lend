export class Car {
    id?: number;
    name?: string;
    model?: string;
    price?: number;
    type?: string;
    kilometer?: number;
    image?: string;
    isAvailable?: boolean;
  }