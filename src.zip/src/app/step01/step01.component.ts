import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-step01',
  templateUrl: './step01.component.html',
  styleUrls: ['./step01.component.css']
})
export class Step01Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
