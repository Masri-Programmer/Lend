import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-svcs',
  templateUrl: './svcs.component.html',
  styleUrls: ['./svcs.component.css']
})
export class SvcsComponent implements OnInit {
  

  constructor() {}

  ngOnInit(): void {
  }
  }

