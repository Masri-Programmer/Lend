export class team {
    id?: number;
    name?: string;
    jobTitle?: string;
    email?: string;
    image?:string;
   
  }